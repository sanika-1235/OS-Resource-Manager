import { useMemo, useState } from "react";
import "./ProcessManagement.css";

const initialProcesses = [
  {
    pid: 1,
    name: "Browser",
    arrivalTime: 0,
    burstTime: 8,
    remainingTime: 8,
    priority: 2,
    state: "RUNNING",
  },
  {
    pid: 2,
    name: "Text Editor",
    arrivalTime: 1,
    burstTime: 5,
    remainingTime: 5,
    priority: 1,
    state: "READY",
  },
  {
    pid: 3,
    name: "File Manager",
    arrivalTime: 2,
    burstTime: 4,
    remainingTime: 4,
    priority: 3,
    state: "NEW",
  },
];

const stateOptions = ["NEW", "READY", "RUNNING", "WAITING"];

function ProcessManagement() {
  const [processes, setProcesses] = useState(initialProcesses);
  const [form, setForm] = useState({
    name: "",
    arrivalTime: "",
    burstTime: "",
    priority: "1",
  });
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");

  const nextPid = useMemo(
    () => Math.max(0, ...processes.map((process) => process.pid)) + 1,
    [processes]
  );

  const counts = {
    total: processes.length,
    running: processes.filter((p) => p.state === "RUNNING").length,
    ready: processes.filter((p) => p.state === "READY").length,
    waiting: processes.filter((p) => p.state === "WAITING").length,
    new: processes.filter((p) => p.state === "NEW").length,
    terminated: processes.filter((p) => p.state === "TERMINATED").length,
  };

  const filteredProcesses = processes.filter((process) =>
    `${process.pid} ${process.name}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  const handleAddProcess = (event) => {
    event.preventDefault();
    setError("");

    const arrival = Number(form.arrivalTime);
    const burst = Number(form.burstTime);
    const priority = Number(form.priority);

    if (!form.name.trim()) {
      setError("Please enter a process name.");
      return;
    }

    if (
      form.arrivalTime === "" ||
      form.burstTime === "" ||
      arrival < 0 ||
      burst <= 0 ||
      priority <= 0
    ) {
      setError("Arrival time must be 0 or more. Burst time and priority must be positive.");
      return;
    }

    const newProcess = {
      pid: nextPid,
      name: form.name.trim(),
      arrivalTime: arrival,
      burstTime: burst,
      remainingTime: burst,
      priority,
      state: "NEW",
    };

    setProcesses((previous) => [...previous, newProcess]);
    setForm({
      name: "",
      arrivalTime: "",
      burstTime: "",
      priority: "1",
    });
  };

  const updateProcessState = (pid, newState) => {
    setProcesses((previous) =>
      previous.map((process) =>
        process.pid === pid ? { ...process, state: newState } : process
      )
    );
  };

  const terminateProcess = (pid) => {
    setProcesses((previous) =>
      previous.map((process) =>
        process.pid === pid
          ? { ...process, state: "TERMINATED", remainingTime: 0 }
          : process
      )
    );
  };

  const resetProcesses = () => {
    setProcesses(initialProcesses);
    setSearch("");
    setError("");
  };

  return (
    <div className="process-page">
      <div className="process-page-heading">
        <div>
          <h2>Process Management</h2>
          <p>Create, monitor and manage system processes.</p>
        </div>
        <button className="process-reset-btn" onClick={resetProcesses}>
          Reset Simulation
        </button>
      </div>

      <div className="process-stats">
        <div className="process-stat-card">
          <span>Total Processes</span>
          <strong>{counts.total}</strong>
          <small>All created processes</small>
        </div>
        <div className="process-stat-card">
          <span>Running</span>
          <strong className="stat-running">{counts.running}</strong>
          <small>Currently executing</small>
        </div>
        <div className="process-stat-card">
          <span>Ready</span>
          <strong className="stat-ready">{counts.ready}</strong>
          <small>Waiting for CPU</small>
        </div>
        <div className="process-stat-card">
          <span>Waiting</span>
          <strong className="stat-waiting">{counts.waiting}</strong>
          <small>Waiting for an event</small>
        </div>
        <div className="process-stat-card">
          <span>Terminated</span>
          <strong className="stat-terminated">{counts.terminated}</strong>
          <small>Completed or stopped</small>
        </div>
      </div>

      <div className="process-content-grid">
        <section className="process-panel process-form-panel">
          <div className="process-panel-heading">
            <div>
              <h3>Create Process</h3>
              <p>Add a new process to the simulation.</p>
            </div>
            <span className="process-heading-icon">＋</span>
          </div>

          <form onSubmit={handleAddProcess} className="process-form">
            <label>
              Process Name
              <input
                type="text"
                placeholder="e.g. Chrome"
                value={form.name}
                onChange={(event) =>
                  setForm({ ...form, name: event.target.value })
                }
              />
            </label>

            <div className="process-form-row">
              <label>
                Arrival Time
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={form.arrivalTime}
                  onChange={(event) =>
                    setForm({ ...form, arrivalTime: event.target.value })
                  }
                />
              </label>

              <label>
                Burst Time
                <input
                  type="number"
                  min="1"
                  placeholder="5"
                  value={form.burstTime}
                  onChange={(event) =>
                    setForm({ ...form, burstTime: event.target.value })
                  }
                />
              </label>
            </div>

            <label>
              Priority
              <input
                type="number"
                min="1"
                placeholder="1"
                value={form.priority}
                onChange={(event) =>
                  setForm({ ...form, priority: event.target.value })
                }
              />
            </label>

            {error && <p className="process-error">{error}</p>}

            <button type="submit" className="process-add-btn">
              + Add Process
            </button>
          </form>
        </section>

        <section className="process-panel process-state-panel">
          <div className="process-panel-heading">
            <div>
              <h3>Process States</h3>
              <p>Current distribution of processes.</p>
            </div>
          </div>

          {stateOptions.map((state) => {
            const count = processes.filter(
              (process) => process.state === state
            ).length;

            return (
              <div className="process-state-row" key={state}>
                <div className="process-state-label">
                  <span className={`state-dot ${state.toLowerCase()}`}></span>
                  <span>{state}</span>
                </div>
                <strong>{count}</strong>
                <div className="process-state-track">
                  <div
                    className={`process-state-fill ${state.toLowerCase()}`}
                    style={{
                      width: `${processes.length ? (count / processes.length) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>
            );
          })}

          <div className="process-state-note">
            <strong>Process lifecycle</strong>
            <p>
              NEW → READY → RUNNING → WAITING / TERMINATED
            </p>
            <small>
              State changes here are simulated for the frontend preview.
            </small>
          </div>
        </section>
      </div>

      <section className="process-panel process-table-panel">
        <div className="process-table-heading">
          <div>
            <h3>Process Table</h3>
            <p>View and manage all processes in the system.</p>
          </div>

          <input
            className="process-search"
            type="text"
            placeholder="Search process..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>

        <div className="process-table-wrapper">
          <table className="process-table">
            <thead>
              <tr>
                <th>PID</th>
                <th>Process Name</th>
                <th>Arrival</th>
                <th>Burst</th>
                <th>Remaining</th>
                <th>Priority</th>
                <th>State</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {filteredProcesses.length > 0 ? (
                filteredProcesses.map((process) => (
                  <tr key={process.pid}>
                    <td className="process-pid">P{process.pid}</td>
                    <td>{process.name}</td>
                    <td>{process.arrivalTime}</td>
                    <td>{process.burstTime}</td>
                    <td>{process.remainingTime}</td>
                    <td>{process.priority}</td>
                    <td>
                      <span
                        className={`process-state-badge ${process.state.toLowerCase()}`}
                      >
                        {process.state}
                      </span>
                    </td>
                    <td>
                      <div className="process-actions">
                        {process.state !== "TERMINATED" ? (
                          <>
                            <select
                              value={process.state}
                              onChange={(event) =>
                                updateProcessState(
                                  process.pid,
                                  event.target.value
                                )
                              }
                              aria-label={`Change state for ${process.name}`}
                            >
                              {stateOptions.map((state) => (
                                <option key={state} value={state}>
                                  {state}
                                </option>
                              ))}
                            </select>
                            <button
                              className="process-terminate-btn"
                              onClick={() => terminateProcess(process.pid)}
                            >
                              Terminate
                            </button>
                          </>
                        ) : (
                          <span className="process-finished">Finished</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="process-empty">
                    No processes found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="process-table-footer">
          Showing {filteredProcesses.length} of {processes.length} processes
        </div>
      </section>

      <p className="process-demo-note">
        Frontend simulation preview — process data is currently stored in
        React state and is not yet connected to the C++ backend.
      </p>
    </div>
  );
}

export default ProcessManagement;
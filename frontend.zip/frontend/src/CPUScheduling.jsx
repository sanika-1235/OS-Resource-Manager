
import { useState } from "react";
import "./CPUScheduling.css";

const initialProcesses = [
  { pid: 1, arrivalTime: 0, burstTime: 5, priority: 2 },
  { pid: 2, arrivalTime: 1, burstTime: 3, priority: 1 },
  { pid: 3, arrivalTime: 2, burstTime: 1, priority: 3 },
];

const algorithms = ["FCFS", "SJF", "SRTF", "Priority", "Round Robin"];

function CPUScheduling() {
  const [algorithm, setAlgorithm] = useState("FCFS");
  const [processes, setProcesses] = useState(initialProcesses);
  const [quantum, setQuantum] = useState(2);
  const [showResults, setShowResults] = useState(false);

  const isDefaultFCFS =
    algorithm === "FCFS" &&
    JSON.stringify(processes) === JSON.stringify(initialProcesses);

  const updateProcess = (index, field, value) => {
    const updated = [...processes];
    updated[index] = { ...updated[index], [field]: value };
    setProcesses(updated);
    setShowResults(false);
  };

  const addProcess = () => {
    const nextId = processes.length
      ? Math.max(...processes.map((p) => p.pid)) + 1
      : 1;

    setProcesses([
      ...processes,
      {
        pid: nextId,
        arrivalTime: 0,
        burstTime: 1,
        priority: 1,
      },
    ]);
    setShowResults(false);
  };

  const removeProcess = (pid) => {
    setProcesses(processes.filter((p) => p.pid !== pid));
    setShowResults(false);
  };

  const runSimulation = () => {
    const invalidProcesses = processes.some(
      (p) =>
        !Number.isInteger(p.arrivalTime) ||
        !Number.isInteger(p.burstTime) ||
        !Number.isInteger(p.priority) ||
        p.arrivalTime < 0 ||
        p.burstTime <= 0 ||
        p.priority < 0
    );

    if (processes.length === 0 || invalidProcesses) {
      alert("Enter valid process values. Burst time must be positive.");
      return;
    }

    if (
      algorithm === "Round Robin" &&
      (!Number.isInteger(quantum) || quantum <= 0)
    ) {
      alert("Time quantum must be a positive integer.");
      return;
    }

    setShowResults(true);
  };

  return (
    <div className="cpu-page">
      <div className="cpu-intro">
        <div>
          <h2>CPU Scheduling Simulator</h2>
          <p>
            Configure processes, choose a scheduling algorithm and analyze
            CPU performance.
          </p>
        </div>
        <span className="cpu-tag">CPU MODULE</span>
      </div>

      <section className="cpu-panel">
        <div className="cpu-panel-heading">
          <div>
            <h3>Scheduling Algorithm</h3>
            <p>Select an algorithm to run the simulation.</p>
          </div>
        </div>

        <div className="algorithm-options">
          {algorithms.map((item) => (
            <button
              key={item}
              className={`algorithm-button ${
                algorithm === item ? "selected" : ""
              }`}
              onClick={() => {
                setAlgorithm(item);
                setShowResults(false);
              }}
            >
              {item}
            </button>
          ))}
        </div>

        {algorithm === "Round Robin" && (
          <div className="quantum-input">
            <label>Time Quantum</label>
            <input
              type="number"
              min="1"
              value={quantum}
              onChange={(e) => {
                setQuantum(Number(e.target.value));
                setShowResults(false);
              }}
            />
          </div>
        )}
      </section>

      <section className="cpu-panel process-panel">
        <div className="cpu-panel-heading process-heading">
          <div>
            <h3>Process Configuration</h3>
            <p>Add and configure processes for scheduling.</p>
          </div>
          <button className="add-process" onClick={addProcess}>
            + Add Process
          </button>
        </div>

        <div className="table-scroll">
          <table className="process-table">
            <thead>
              <tr>
                <th>Process ID</th>
                <th>Arrival Time</th>
                <th>Burst Time</th>
                <th>Priority</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {processes.map((process, index) => (
                <tr key={process.pid}>
                  <td>
                    <span className="pid-badge">P{process.pid}</span>
                  </td>

                  {["arrivalTime", "burstTime", "priority"].map((field) => (
                    <td key={field}>
                      <input
                        className="process-input"
                        type="number"
                        min={field === "burstTime" ? "1" : "0"}
                        value={process[field]}
                        onChange={(e) =>
                          updateProcess(
                            index,
                            field,
                            Number(e.target.value)
                          )
                        }
                      />
                    </td>
                  ))}

                  <td>
                    <button
                      className="remove-process"
                      onClick={() => removeProcess(process.pid)}
                      aria-label={`Remove process ${process.pid}`}
                    >
                      ×
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="simulation-actions">
          <span>{processes.length} processes configured</span>
          <button className="run-simulation" onClick={runSimulation}>
            ▶ Run Simulation
          </button>
        </div>
      </section>

      {showResults && isDefaultFCFS ? (
        <section className="cpu-results">
          <div className="results-heading">
            <div>
              <h3>Scheduling Results</h3>
              <p>FCFS · Sample preview using the default processes</p>
            </div>
            <span className="result-badge">Demo data</span>
          </div>

          <div className="result-stats">
            <div className="result-stat">
              <span>Average Turnaround Time</span>
              <h2>6.33</h2>
              <small>Time units</small>
            </div>
            <div className="result-stat">
              <span>Average Waiting Time</span>
              <h2>3.33</h2>
              <small>Time units</small>
            </div>
            <div className="result-stat">
              <span>Average Response Time</span>
              <h2>3.33</h2>
              <small>Time units</small>
            </div>
            <div className="result-stat">
              <span>CPU Utilization</span>
              <h2>100%</h2>
              <small>Sample execution</small>
            </div>
          </div>

          <div className="cpu-panel gantt-panel">
            <div className="cpu-panel-heading">
              <h3>Gantt Chart</h3>
              <p>Process execution timeline</p>
            </div>

            <div className="gantt-chart">
              <div className="gantt-block block-p1">
                <strong>P1</strong>
                <span>0 – 5</span>
              </div>
              <div className="gantt-block block-p2">
                <strong>P2</strong>
                <span>5 – 8</span>
              </div>
              <div className="gantt-block block-p3">
                <strong>P3</strong>
                <span>8 – 9</span>
              </div>
            </div>

            <div className="gantt-timeline">
              <span>0</span>
              <span>5</span>
              <span>8</span>
              <span>9</span>
            </div>
          </div>

          <div className="cpu-panel">
            <div className="cpu-panel-heading">
              <h3>Process Metrics</h3>
              <p>Execution details for each process</p>
            </div>

            <div className="table-scroll">
              <table className="process-table">
                <thead>
                  <tr>
                    <th>Process</th>
                    <th>Completion Time</th>
                    <th>Turnaround Time</th>
                    <th>Waiting Time</th>
                    <th>Response Time</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>P1</td><td>5</td><td>5</td><td>0</td><td>0</td>
                  </tr>
                  <tr>
                    <td>P2</td><td>8</td><td>7</td><td>4</td><td>4</td>
                  </tr>
                  <tr>
                    <td>P3</td><td>9</td><td>7</td><td>6</td><td>6</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>
      ) : showResults ? (
        <section className="cpu-panel result-notice">
          <h3>Configuration ready</h3>
          <p>
            Your {algorithm} inputs are ready. Actual Gantt chart and
            scheduling metrics will appear after connecting the C++ backend.
          </p>
          <span>Backend integration pending</span>
        </section>
      ) : null}
    </div>
  );
}

export default CPUScheduling;
